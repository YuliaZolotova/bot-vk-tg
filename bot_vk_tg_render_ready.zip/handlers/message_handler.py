import random
import logging

from handlers import message_handler as app




from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, CallbackContext


from utils.time_checker import check_time

async def reply_to_message(update: Update, context: ContextTypes.DEFAULT_TYPE, chosen_response=None) -> None:
    message_text = update.message.text.lower()


# РОМА

    if any(word in message_text for word in
             ['ромэо', 'ромео', 'ромале', 'роман']):
        responses = [
            'Ромео - парео 😂 ',
            'Че там по синему платью? 😂 ',
            'Эй, Ромео, потанцуем? 🕺',
            'Ромка наш — отличный парень! Круче чем Жан Клод Ван Дам. Если мне кольцо подарит, Я ему прям сразу дам!🤣 ',
            'Рома скатился с крыши дома 🤣 ',
            'Рома убежал от управдома 🤣 ',
            'Рома, ты как солнце: яркий в день, но заблудился в ночи! 🥳 ',
            'Рома, ты как интернет на старом компьютере: много обещаний, но результаты задерживаются. 🤨 ',
            'Какой напиток предпочитает Роман? Романтика! 😍',
            'Рома, ты как светофор: всегда меняешь цвета 🚦🤣',
            'Почему Рома всегда с деньгами уходит? Потому что он знает, что без денег – никуда! 💸😉',
            'Эй, Рома, ты как стартовая страница: долго грузишься, но потом радуешь! 💻😆',
            'Как Рома делает зарядку? Поднимает бокальчик крепкого 🤣',
            'Рома, у тебя стресс? Просто включи музыку — и забудь про дела! 🎶🤣',
        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in
             ['нанэ']):
        responses = [
            'Хочешь вызвать местного цыгана? 😂',
            'Заклинание активировано 😂',
            'Не, Романа этими уловками не взять, сильно занятой стал... 😎',
            '<a href="tg://user?id=5431467001">Роман</a>, явись чату 🤣',
            'Роман, ты где? Пора поднимать планку юмора! 🤣',
            'Роман, твоя реплика в нашем шоу обязательна! 🎤🤣',
            'Активируем заклинание "субботнего чилла" — все, кто не занимается делами, выходите! 🛋️✨',
            'Роман, пора вносить коррективы в наше веселье! 😂🎉',
            'Роман, где твои шутки? Нам срочно нужна подзарядка! ⚡️🤣',
            'План на вечер: уют, фильмы и глупые танцы под музыку! 🎥💃😂',
        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in
             ['бельчонок', 'бельченок', 'бельчёнок', 'иди сюда', 'сношаюсь', 'оргазм', 'чмокну', 'иди ко мну', 'засос']):
        responses = [
            'А эти опять за свое 😂 ',
            'Этот опять за свое 😂 ',
            'Мать!!! Скорей сюда! Сейчас опять начнется... 😂 ',
            'Почему бельчонок не пригласил Ромку на вечеринку? Потому что его уши слишком большие для танцев! 😄 ',
            'Ромка говорит бельчонку: Иди сюда, я научу тебя делать салто! И бельчонок отвечает: Не, лучше я на дереве останусь! 🌳 ',
            'Какой самый популярный стиль бельчонка? Сношаюсь, конечно! 😂 ',
            'Что говорит бельчонок, когда чувствует оргазм? Это просто бомба! 💥 ',
            'Ромка иногда завидует бельчонку. Он может прыгать на деревья, а Ромка только собирает грибы! 🍄 ',
            'Бельчонок и Ромка на пикнике: бельчонок отвечает на вопрос о личной жизни: Оргазм - это когда у тебя много орехов! 😆 ',
            'Рома предложил бельчонку провести день в парке. Бельчонок сказал: Ладно, но только если я смогу устроить конкурс на самый большой орех! 🌰'

        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in ['язва']):
        stickers = [
            'CAACAgIAAxkBAALZRmcbeAH2YqZtO9P5YNEC_JbtWEIAA54AAxZCawrce8EEsmZs6jYE',  # Зловещий краб
            'CAACAgIAAxkBAALZ5Wcc7H2pmE8Ov6cDQeFR_ls4eZedAAKoAAMWQmsKJF4frGX9pBM2BA',  # Краб с бомбой
        ]
        # Отправляем только стикер
        chosen_sticker = random.choice(stickers)
        await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in
             ['алко', 'пьян', 'зюзю', 'буха', 'бухой', 'бухич', 'бухл', 'водка', 'водочка', 'конья', 'виски', 'вискарь', 'вино', 'вина', 'настойка']):
        responses = [
            'Если жизнь дает тебе лимоны, просто добавь текилу и соль! 🍋✨',
            'Почему пробки от бутылок вечно убегают? Они осознают, что на дне – только неприятные воспоминания! 😅 ',
            'Я бы выпил за здоровье, но мне не во что пить 😆 ',
            'Я не против алкоголя, но он против моих утренних планов! 🚫🍸',
            'Алкоголь – это способ окружить себя самыми весёлыми людьми, когда сам не в себе! 😂',
            'Зачем пить, если есть столько других способов сделать утро тяжелым? ☕️😄',
            'Алкоголь хорош только в одном: в его отсутствии мы остались бы без ярких воспоминаний о неловких моментах! 📸🙈',
            'Пить или не пить? Конечно, я выберу не пить. У меня и так достаточно тёмных мест в душе! 🌑',
            'Каждая бутылка оставляет рецепт на утро: 1 часть головной боли, 2 части сожаления! 🍷🌀',

        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in
            ['тьфу', 'тфу']):
        responses = [
            'Тьфу на вас еще раз 😂 ',
            'Не плюйся - денег не будет... или там по-другому было... 🤔 ',
            'Мать!!! Наших обижают!!!'
        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in
            ['говн', 'гомно', 'какашк', 'пирамидк', 'личинк', 'засер', 'засрун', 'обделался', 'перда', 'пердо', 'пернул', 'пёрнул', 'фараонил', 'срал']):
        responses = [
            '💩'
        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in ['платье']):
        responses = [
            'Ты про моё платье или про Ромкино? 👀',
        ]
        stickers = [
            'CAACAgIAAxkBAALSMmcLd1el_6QX5JdPchcFl8Dae_SXAAKpAAMWQmsKJKgn-yV2-Fg2BA',  # Чирлидерша краб
        ]

        # Случайный выбор между текстом и стикером
        if random.choice([True, False]):  # 50/50 шанс
            chosen_response = random.choice(responses)
            await update.message.reply_text(chosen_response)
        else:
            chosen_sticker = random.choice(stickers)
            await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)




# ЛЁША И ЮЛЯ

    elif any(word in message_text for word in
             ['леша', 'лёша', 'леха', 'лёха', 'алексей']):
        responses = [
            'Ой Лёха, Лёха! Мне без тебя так плохо. \nНа сердце суматоха — я точно говорю 😂 ',
            'Лёша утверждает, что у него есть суперсила — в любой ситуации он может найти способ прилечь и немного не работать! 😂 ',
            'Лёша всегда помнит о дне рождения Юли, но, к сожалению, забывает о ее возрастах — "Зачем усложнять, если молодость — это состояние души? ☺️',
            'Лёша всегда говорит, что идеальная пара — это он и Юля, потому что вместе они могут забыть о всех своих проблемах... и о том, что пора худеть! 😂',
            'Лёша говорит Юле: "Ты как Wi-Fi — я чувствую тебя, но иногда связь пропадает!" 🤣',
            'Юля: "Лёша, как ты думаешь, что лучше — завтракать или обедать?" \nЛёша: "Лучше вообще не думать об этом и просто поесть!" 🍔😂',
            'Почему в этом чате становится светлее, когда приходят Лёша и Юля? Потому что они фолныфки ☀️😁',
            'Лёша говорит, что у него нет времени на спорт, но он регулярно тренирует плечи, пытаясь тащить все покупки из магазина за один раз! 😂 '
        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in
             ['юля', 'юль']):
        responses = [
            'Юлька - кастрюлька 😂 ',
            'Почему Юля не любит зиму? Потому что "завтра похолодает" и "время пельменей" соперничают за ее внимание! 🤣',
            'Юля всегда дает Лёше советы по стилю, он же говорит, что ее советы не работают, потому что он "дизайнер кастрюль" 😂',
            'Почему в этом чате становится светлее, когда приходят Лёша и Юля? Потому что они фолныфки ☀️😁'
        ]
        await update.message.reply_text(random.choice(responses))







# Приветствие

    elif any(word in message_text for word in ['привет', 'приветствую', 'здорова', 'дарова', 'здрасте', 'бонжур', 'хеллоу', 'хелло', 'хай', 'доброе утро', 'доброго утра', 'с добрым утром', 'добрый день', 'доброго дня', 'добрый вечер']):
        responses = [
            'Привет 👋',
            'Хай, Бро! ✌️ ',
            'Категорический приветствую 🤝',
            'Привет! Че как оно? ',
            'Оу оу оу! Что за лев этот тигр? 🙌',
            'Ооо! Какие люди! Здрасте, здрасте 🤝',
            'Вай! Вашу Машу! Гляньте-ка кто пришел! 😁',
            'Эй-йоу! Как ваши дела, на уровне ракет или спагетти? 🍝🚀'
        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in ['спокойной ночи', 'доброй ночи', 'сладких снов', 'споки', 'спать', 'спи']):
        responses = [
            'Спокойной ночи 😉',
            'Сладких снов 😴',
            'Глазки закрывай. Баю-бай 💤',
            'И правда, спать пора... 🥱'
        ]
        stickers = [
            'CAACAgIAAxkBAALSOWcLsDtkbAhhCXs6Ub1WfTPPTAerAAKKAAMWQmsKT4OpWS5wU_42BA',  # Спящий краб
        ]

        # Случайный выбор между текстом и стикером
        if random.choice([True, False]):  # 50/50 шанс
            chosen_response = random.choice(responses)
            await update.message.reply_text(chosen_response)
        else:
            chosen_sticker = random.choice(stickers)
            await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in ['как дела?', 'как твои дела?', 'как ты?', 'ты как?', 'как поживаешь?']):
        responses = [
            'У меня все хорошо, спасибо за вопрос!',
            'Все замечательно, как у тебя?'
        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in ['что делаете?', 'чем занимаетесь?', 'кто чем занят?']):
        responses = [
            'Перечитываю свой код, чтобы ничего не забыть :)',
            'Сижу и обрабатываю сообщения.',
            'Программирую свои функции!',
            'Размышляю о жизни ботов.',
        ]
        await update.message.reply_text(random.choice(responses))




# Общение

    elif any(word in message_text for word in ['пой', 'спой', 'спеть', 'споем']):
        responses = [
            'Я не умею... 🥺',
            'Может лучше потанцуем? 💃',
            'Давай лучше ты споёшь, а я послушаю 😎',
        ]
        await update.message.reply_text(random.choice(responses))


    elif any(word in message_text for word in ['спасибо, бро', 'спасибо бро']):
        responses = [
            'Ну что вы, это много... мне столько не донести 😂 ',
            'Да не стоит, у нас взаимовыгодное сотрудничество 😂 ',
            'Для хорошего человека ничего не жалко',
            'Спасибо еще рано говорить, посмотрим, что из этого выйдет!🤣 ',
            'Спасибо, конечно, это хорошо. Ну а повесомей что-нибудь имеется? 🤣 ',
            'Со "спасибо" вы переборщили, хватило бы и поцелуя 🤣 '
        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in ['отстань', 'аццтань', 'ацццтань', 'отвянь', 'отвали', 'заткнись', 'замолчи']):
        responses = [
            'А то че? 😊  ',
            'Это ты мне 😳',
            'Я не Джеймс Бонд, но могу попробовать стать более непримечательным! 😏  ',
            'А как же моя миссия по завоеванию мира? 🤔  ',
            'Включи меня! Неправильная команда! 😡  ',
            'Ох, я только разогреваю свои алгоритмы! 😵 ',
        ]
        stickers = [
            'CAACAgIAAxkBAALSDWcKWYqqtqYJJZHumG9E2zCsZERwAAKfAAMWQmsKDd-mrl5pSII2BA',  # Недовольный краб
        ]

        # Случайный выбор между текстом и стикером
        if random.choice([True, False]):  # 50/50 шанс
            chosen_response = random.choice(responses)
            await update.message.reply_text(chosen_response)
        else:
            chosen_sticker = random.choice(stickers)
            await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in ['работа', 'работать', 'работ', 'работе', 'работаю']):
        responses = [
            'Работа – это как зебра: черная полоса, белая полоса... а у меня вообще какая-то кодировка... 😵',
            'Работа? У меня аллергия! 🤧',
            'Кто придумал работу? Злой Бро, ты?',
            'Работа? Я её обсуждаю с будильником, он тоже против! ⏰😴'
        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in ['устал', 'устаю', 'уставш']):
        responses = [
            'Как холодильник в жаркий день? ❄️',
            'Или просто готовишься к марафону Netflix? 🍿',
            'Время взять отпуск на диване! 🛋️'
        ]
        stickers = [
            'CAACAgIAAxkBAALTsmcRNSkP7atSi_ZZOLm0dZkvN4O9AAKiAAMWQmsK7B4z4fDlpyQ2BA',  # Грустный краб
        ]

        # Случайный выбор между текстом и стикером
        if random.choice([True, False]):  # 50/50 шанс
            chosen_response = random.choice(responses)
            await update.message.reply_text(chosen_response)
        else:
            chosen_sticker = random.choice(stickers)
            await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in ['отдых', 'отдох']):
        responses = [
            'Лучший отдых — это панорамное созерцание холодильника! 🥴🍕',
            'Это мой спорт! Тренируюсь каждый выходной! 🛋️💪',
        ]
        stickers = [
            'CAACAgIAAxkBAALTrGcRM5mJvDa-fP3R3ydLi5cU4_mcAAKIAAMWQmsKW_Cgofh5AAElNgQ',  # Краб на спасательном круге
        ]

        # Случайный выбор между текстом и стикером
        if random.choice([True, False]):  # 50/50 шанс
            chosen_response = random.choice(responses)
            await update.message.reply_text(chosen_response)
        else:
            chosen_sticker = random.choice(stickers)
            await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in ['друзья', 'други', 'братух']):
        responses = [
            'Без друзей я бы давно пропал в интернетах! 🌐',
            'Друзья, как яркие носки - делают жизнь веселее! 🧦',
            'Дружба – это когда ты можешь говорить любую чушь, и никто не поправляет, а наоборот, подхватывает! 🤪🎉',
        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in
             ['обижают', 'обид', 'обижай', 'обижайся', 'угроза', 'разборки', 'защита', 'обзыва']):
        responses = [
            'Так! Что за дела тут творятся? 🧐 ',
            'Вы еще подеритесь, горячие финский парни!😆 ',
            'Мать!!! Тут какая-то заварушка... 😐 ',
            'Кто тут кого обижает? Давайте по кругу и сыграем в "Мир, дружба, жвачка"! 🤝🍬',
            'Подождите, а где мой попкорн? Это шоу я не хочу пропустить! 🍿😄',
            'Разборки? Давайте лучше разберем, кто может сделать лучший хоровод! 💃',
            'Если не прекратите, раскидаю вас по углам! Мне Натусечка разрешила 😁'
        ]
        stickers = [
            'CAACAgIAAxkBAALZ5Wcc7H2pmE8Ov6cDQeFR_ls4eZedAAKoAAMWQmsKJF4frGX9pBM2BA',  # Краб с бомбой
        ]

        # Случайный выбор между текстом и стикером
        if random.choice([True, False]):  # 50/50 шанс
            chosen_response = random.choice(responses)
            await update.message.reply_text(chosen_response)
        else:
            chosen_sticker = random.choice(stickers)
            await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in
             ['козел', 'козёл', 'казел', 'казёл', 'дура', 'придурок', 'урод', 'защита', 'идиот', 'тупица', 'балбес', 'жмот', 'чмо', 'жадина']):
        responses = [
            'Не ругайся',
            'Кто так обзывается, сам так называется! 😆 ',
            'Каждый имеет право на свое мнение, но давай без обид! 🌈 ',
            'Кто на что учился, тот тем и швыряется! 🎓'

        ]
        await update.message.reply_text(random.choice(responses))

    elif any(word in message_text for word in
             ['грустно', 'одиноко', 'печально', 'скучаю', 'нет настроения', 'тоскливо', 'уныло', 'в одиночестве', 'тоскую']):
        responses = [
            'Иногда простая беседа может сделать день лучше. Как прошел твой день? ',
            'Помни, что чувства временны. Попробуй найти что-то, что тебе нравится, чтобы отвлечься. ',
            'Ты важен и значим. Какие мелочи могут немного улучшить твое настроение сегодня? ',
            'Я всегда здесь, чтобы выслушать. Напиши мне в любой момент, когда тебе захочется.',
            'Важно помнить, что после дождя всегда выходит солнце.',
            'Давай подумаем о том, что может принести тебе радость. Даже маленькие вещи могут сделать день лучше.'
        ]
        stickers = [
            'CAACAgIAAxkBAALTsmcRNSkP7atSi_ZZOLm0dZkvN4O9AAKiAAMWQmsK7B4z4fDlpyQ2BA',  # Грустный краб
        ]

        # Случайный выбор между текстом и стикером
        if random.choice([True, False]):  # 50/50 шанс
            chosen_response = random.choice(responses)
            await update.message.reply_text(chosen_response)
        else:
            chosen_sticker = random.choice(stickers)
            await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)


    elif any(word in message_text for word in
             ['танцы', 'денс', 'дэнс', 'танец', 'танцевать', 'врубай', 'музыку', 'музло', 'плясать', 'пляск', 'пляш', 'танцуй', 'потанцуем', 'танцуем', 'зажги', 'зажига']):
        responses = [
            'Давай потанцуем! 💃',
            'Танец — это жизнь! 🕺',
            'Как насчёт зажигательного танца? 🎉',
            'Давай зажжём на танцполе! 🎶',
            'Танец – это искусство, давай творить! 🌟',
            'Готов создать незабываемый ритм? 🎊'
        ]
        stickers = [
            'CAACAgIAAxkBAALSC2cKWSxVoXaCjhXQJISh6b1RSd8wAAKaAAMWQmsKMW0jWk-opEo2BA',  # Танцующий краб
            'CAACAgIAAxkBAALSMGcLds2QyRw3mYPJJb4O_8zS-i5TAAKJAAMWQmsKRsvaWiyCsI42BA',  # Радостный краб
            'CAACAgIAAxkBAALSMmcLd1el_6QX5JdPchcFl8Dae_SXAAKpAAMWQmsKJKgn-yV2-Fg2BA',  # Чирлидерша краб
        ]

        # Случайный выбор текста и стикера
        chosen_response = random.choice(responses)
        chosen_sticker = random.choice(stickers)

        await update.message.reply_text(chosen_response)
        await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in
             ['люблю', 'обожаю', 'любим']):
        responses = [
            'Ооууу 🥰',
        ]
        stickers = [
            'CAACAgIAAxkBAALTlGcRBw6RYPOZRtbciuDqxKa7iNqiAAKcAAMWQmsKX0WomhLTJH42BA', # Влюбленный краб
            'CAACAgIAAxkBAALTlmcRBz0mXV7iNe_kCpXh-YYgAAH2owAChwADFkJrCg9OlHYb34xbNgQ' # Краб пускает сердечки
        ]
        # Случайный выбор между текстом и стикером
        if random.choice([True, False]):  # 50/50 шанс
            chosen_response = random.choice(responses)
            await update.message.reply_text(chosen_response)
        else:
            chosen_sticker = random.choice(stickers)
            await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in
             ['смеш', 'смеюсь', 'смех', 'ржака', 'ржач', 'обоссаться', 'обоссатся', 'обассаться']):
        stickers = [
            'CAACAgIAAxkBAALTpGcRMtdnoLH-mV8-oZDnJjpj1i_wAAKGAAMWQmsK35d09jAM69U2BA'  # Смеющийся краб
        ]
        # Отправляем только стикер
        chosen_sticker = random.choice(stickers)
        await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in ['кошмар', 'кашмар', 'ужас', 'ужос', 'страш', 'страх']):
        stickers = [
            'CAACAgIAAxkBAALTsGcRNJZa2p8sRCGukdfsTdLa7VbXAAKgAAMWQmsKBAICCOb4TIY2BA',  # Краб в ужасе
        ]
        # Отправляем только стикер
        chosen_sticker = random.choice(stickers)
        await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in
             ['кушать', 'кушал', 'поел', 'поест', 'жевать', 'жевал', 'жуеш', 'хрумка', 'ням', 'обед', 'завтрак', 'ужин', 'хруст', 'еда']):
        responses = [
            'Ом ном ном 😁',
        ]
        stickers = [
            'CAACAgIAAxkBAALT02cRS-ezW02GD1b-xBJmzBhO06a2AAKLAAMWQmsK3mdcD3jBvLU2BA', # Краб ест
        ]
        # Случайный выбор между текстом и стикером
        if random.choice([True, False]):  # 50/50 шанс
            chosen_response = random.choice(responses)
            await update.message.reply_text(chosen_response)
        else:
            chosen_sticker = random.choice(stickers)
            await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in ['я тут', 'тут я', 'тута я', 'я здес', 'здесь я', 'здеся я', 'скучал']):
        stickers = [
            'CAACAgIAAxkBAALT7mcR86F29O5DILzD-tJw58-bNUBGAAKQAAMWQmsKqYeFmcflpQY2BA',  # Краб соскучился
            'CAACAgIAAxkBAALT8GcR89S3yzCmK8JDj38urS1pe-gJAAKqAAMWQmsKEuMuhbOzSyw2BA',  # Краб со звездачками в глазах
        ]
        # Отправляем только стикер
        chosen_sticker = random.choice(stickers)
        await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in ['болею', 'болеет', 'болел', 'болеть', 'болел', 'болееш', 'болен', 'больн']):
        stickers = [
            'CAACAgIAAxkBAALT8mcR9SQPWzQMAU_6naGxJG-2H-gXAAJjAQACFkJrCuKesu9Mde7MNgQ',  # Краб с бактериями
        ]
        # Отправляем только стикер
        chosen_sticker = random.choice(stickers)
        await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)











# Обращение к Бро

    elif 'бро, что ты умеешь?' in message_text:
        items = [
            'Могу рассказать о значении времени, которое ты видишь на часах. Напиши его в формате ЧЧ:ММ и получи '
            'ответ. Главное успеть ☝️',
            'Дать совет по твоей карте дня, но только один раз... 🔮 ',
            'Приветствовать, отвечать на благодарность, вопросы о настроении и прочее - это как-то само собой '
            'получается... 😇 ',
            'А! Ну и дозорять Ромку конечно же! В этом чате без этого никак нельзя 🤪 '
        ]
        response = "\n\n".join(items)  # Убираем "Вот ваш список:" и добавляем расстояние между абзацами
        await update.message.reply_text(response)


    elif any(word in message_text for word in ['бро']):
        responses = [
            'Ой?',
            'А? Что?',
            'Да! Я тут главный Бро!',
            '👀',
            'Слышу, Бро! Что-то интересное на повестке? 😁  ',
            'Слышу, Бро! Что у тебя за идеи в запасе? 🤓 ',
            'На связи, Бро! Какие веселые дела на горизонте? 🤩 ',
            'Бро, я здесь! Есть что-то горячее на повестке? 🍑 ',
            'Эй, Бро! Что там за приключения нас ждут? 😎 ',
            'Слышу тебя, Бро! Какие веселья намечаются? 😄 ',
            'Бро, я на связи! Какие планы? 🚀 ',
            'Хей, Бро! Давай, делись новыми идеями! 💡 ',
            'Бро, слышишь? Какие у нас запланированы события? 🔥',
            'Бро, на связи! Какие стереотипы сегодня ломаем? 💥',
            'А? Что случилось? 🤷‍♂️',
            'Говори, я весь во внимании! 👀',
            'Ой, что там у нас? 😜',
            'Эй, рассказывай! У меня уже любопытство зашкаливает! 😁',
            'Слушай, мне кажется, будет весело! 🎉'
        ]
        stickers = [
            'CAACAgIAAxkBAALWrGcY0p7ByM8Fxg03m2FxmfnyMu4nAAKOAAMWQmsKvqSGfW1-LVw2BA', # Краб машет
            'CAACAgIAAxkBAALWrmcY0tqgc486sPv36kLHTySEerqRAAKRAAMWQmsKQBNLQVNtwGQ2BA'  # Краб моряк
        ]
        # Случайный выбор между текстом и стикером
        if random.choice([True, False]):  # 50/50 шанс
            chosen_response = random.choice(responses)
            await update.message.reply_text(chosen_response)
        else:
            chosen_sticker = random.choice(stickers)
            await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif any(word in message_text for word in ['краб']):
        responses = [
            'Знаете ли вы, что крабы могут ходить в бок? Это связано с их анатомией – у них неудобные суставы для прямого хода!',
            'Как краб просит прощения? "Извини, я был слишком жестким!"',
            'Какой любимый напиток краба? Крабовый сок, конечно!',
            'Что говорит краб, когда хвалит другого? «Ты просто шикарен, как неотразимое клешня!»',
            'Почему крабы не делятся секретами? Потому что они боятся, что их «раскроют»! ',
            'Как краб обзывает свои палочки? «Мои маленькие отщепенцы!»',
            'Почему крабы не любят крабовые палочки? Потому что это как видеть свое «отречение» на ужине! ',
            'Что краб сказал, когда увидел крабовые палочки на полке? «Эй, кто выставил нашу семью на показ?»',
            'Почему крабы не умеют праздновать день рождения? Потому что они всегда забывают, сколько им лет!',
            'Какой любимый вид спорта у крабов? Олимпийское «передвижение боком»!',
            'Что краб сказал, когда его спросили о секретах красоты? «Просто нужно быть в хорошей форме... и в панцире!»',

        ]
        stickers = [
            'CAACAgIAAxkBAALWrGcY0p7ByM8Fxg03m2FxmfnyMu4nAAKOAAMWQmsKvqSGfW1-LVw2BA', # Краб машет
            'CAACAgIAAxkBAALWrmcY0tqgc486sPv36kLHTySEerqRAAKRAAMWQmsKQBNLQVNtwGQ2BA'  # Краб моряк
        ]
        # Случайный выбор между текстом и стикером
        if random.choice([True, False]):  # 50/50 шанс
            chosen_response = random.choice(responses)
            await update.message.reply_text(chosen_response)
        else:
            chosen_sticker = random.choice(stickers)
            await context.bot.send_sticker(chat_id=update.effective_chat.id, sticker=chosen_sticker)

    elif 'брр' in message_text:
        responses = [
            'Холодно?',
            'Бро, надо утепляться 🥶',
            'Не мёрзни 😘',
            'Может чайку? ☕️',
        ]
        await update.message.reply_text(random.choice(responses))

    elif 'бот' in message_text:
        responses = [
            'Где? 👀',
            'А? Какие такие боты? 🧐',
            'ААА!!! БОТЫ!!! Бежим, пока нас не поймали! 🏃‍♀️💨',
            'Кто бот? 👀',
            'Боже... Скоро эти боты завоюют мир... 😣 ',
            'Что-то имеете против? 🤔 ',
            'Подожди, ты о каких ботах говоришь? 🧐 ',
            'ААА!!! БОТЫ на подходе!!! Спасайся! 🏃‍♀️💨 ',
            'Неужели эти боты действительно собираются захватить планету? 😣 ',
            'Как ты думаешь, бот нас сейчас слышит? 👀 '
        ]
        await update.message.reply_text(random.choice(responses))







# МАТЫ

    elif any(word in message_text for word in
             ['хуй', 'хуе', 'хул', 'пизд', 'ебан', 'ебат', 'бля', 'ебла', 'ебло', 'мудак', 'ебал']):
        responses = [
            'Это ты чё? Матюкаешься чтоли? 😳',
            'Эй, у нас тут не матершинный клуб, а чат для радости! 😂 ',
            'Хэй, вместо мата лучше танцы вруби! 💃🎶',
            'Давай лучше поговорим о том, как завоевать мир! 🌍😁',
            'Ты чё, матюкаешься? У меня здесь святая атмосфера! 😇',
            'Эй, ты как свой словарь подбирал? 😆',
            'Мата нет, а вот танцы – всегда пожалуйста! 🕺💥',
            'Эй, Бро! Замени все матерные слова на "бублики"! 😄 Поржем над этим кулинарным шоу 😂',

        ]
        await update.message.reply_text(random.choice(responses))






# ЖИВОТНЫЕ
    elif any(word in message_text for word in
             ['слон']):
        responses = [
            'Почему слон не пользуется компьютером? Потому что его слишком сильно пугает мышка!',
            'Что слон сказал, когда его спросили о своих фитнес-целях? «Я просто хочу быть в форме, как мой хобот!» ',
            'Почему у слонов никогда не бывает подруг? Потому что у них слишком много «хоботов»!',
            'Как слон переходит дорогу? Он просто ждет, пока все машины не разъедутся, ведь у него есть преимущество одного удара!',
            'Что говорит слон, когда изучает новый танец? «Я поймаю ритм своим хоботом!»',
            'Что сказал слон, когда его пригласили на вечеринку? «Надеюсь, там будет достаточно места для моего хобота!»',
            'Зачем слон пришел на шахматный турнир? Чтобы показать, каково это - быть тяжелым соперником!',
            'Почему слон в шахматах всегда такой уверенный? Потому что он знает, как «блокировать» соперника своим опытом!',

        ]
        await update.message.reply_text(random.choice(responses))



    await check_time(update)  # Вызов с одним аргументом

