# constants.py

# Токен вашего Telegram-бота
TOKEN = ""  # moved to TG_TOKEN env var  # Замените на настоящий токен

# URL-адреса или API-ключи (если есть)
# API_URL = "https://api.your_service.com"  # Пример URL для API

# Прочие константы
WELCOME_MESSAGE = "Добро пожаловать в наш бот! Как я могу помочь вам?"
ERROR_MESSAGE = "Что-то пошло не так. Пожалуйста, попробуйте еще раз."
